#!/bin/bash

while true
do
./wildrig-multi --print-full --algo minotaur --url stratum+tcp://stratum-eu.rplant.xyz:7018 --user Zq4Qy3txJozx7Qr7ngJ9xLnyG4pzcREaie
sleep 5
done
