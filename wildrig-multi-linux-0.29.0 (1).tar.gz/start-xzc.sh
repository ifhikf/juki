#!/bin/bash

while true
do
./wildrig-multi --print-full --algo mtp --opencl-threads auto --opencl-launch auto --url stratum+tcp://zcoin-eu.mintpond.com:3000 --user a8MjPUoCjm9pLvX4TRDRfTCA7wcNDa19cM --pass x
sleep 5
done
