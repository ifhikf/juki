#!/bin/bash

while true
do
./wildrig-multi --megabtx megabtx --opencl-threads auto --opencl-launch auto --url pool:port --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2 --pass password
sleep 5
done
