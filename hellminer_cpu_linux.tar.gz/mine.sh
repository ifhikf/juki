./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2.hellminer -p x --cpu 2
